

print(int(round(2.0)) )